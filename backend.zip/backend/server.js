const express = require('express');
const mysql = require('mysql')
const cors = require('cors')
const bodyParser = require('body-parser')

const app = express()
app.use(cors())

const db = mysql.createConnection({
            host: 'localhost',
            user:'root',
            password:'Bbs@09112002',
            database:'test',
            port:'3306'
})
db.connect();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
// app.get('/',(re,res) =>{
//     return res.json('From Backend Side');
// })
// app.get('/users',(req,res)=>{
//     const sql = "SELECT  * FROM users";
//     db.query(sql,(err,data)=>{
//         if(err) return res.json(err);
//         return res.json(data);
//     })
// })
//Student


// POST a new student
app.post('/Student', (req, res) => {
    const {FName,MName,LName,Student_ID,Course_Department,Email,Phone_Number, password } = req.body;
    const sql = "INSERT INTO Student (Student_ID, FName,MName,LName,Course_Department,Email,Phone_Number) VALUES (?, ?, ?, ?, ?, ?, ?)";
    db.query(sql, [Student_ID,FName,MName,LName,Course_Department,Email,Phone_Number], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.status(201).json({ message: "Student added successfully", id: result.insertId });
    });
});

// PUT (update) the student info
app.put('/Student/:Student_ID', (req, res) => {
    const StudentId = req.params.Student_ID;
    const { FName,MName,LName } = req.body;
    const sql = "UPDATE Student SET FName = ?, MName = ?, LName = ? WHERE Student_ID = ?";
    db.query(sql, [FName,MName,LName, StudentId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Product not found" });
        }
        return res.json({ message: "Product updated successfully" });
    });
});
app.put('/Student/:Student_ID', (req, res) => {
    const StudentId = req.params.Student_ID;
    const { Email } = req.body;
    const sql = "UPDATE Student SET Email = ? WHERE Student_ID = ?";
    db.query(sql, [Email, StudentId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Product not found" });
        }
        return res.json({ message: "Product updated successfully" });
    });
});
app.put('/Student/:Student_ID', (req, res) => {
    const StudentId = req.params.Student_ID;
    const { Phone_Number } = req.body;
    const sql = "UPDATE Student SET Phone_Number =  ? WHERE Student_ID = ?";
    db.query(sql, [Phone_Number, StudentId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Product not found" });
        }
        return res.json({ message: "Product updated successfully" });
    });
});


//Employee

// GET all Employees
app.get('/Employee', (req, res) => {
    const sql = "SELECT * FROM Employee";
    db.query(sql, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json(data);
    });
});

// POST a new Employee
app.post('/Employee', (req, res) => {
    const { Emp_Id,EFName,EMName,ELName,Designation,Emp_Email,Emp_Contact_Number,D_id} = req.body;
    const sql = "INSERT INTO products (Emp_Id,EFName,EMName,ELName,Designation,Emp_Email,Emp_Contact_Number,D_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    db.query(sql, [Emp_Id,EFName,EMName,ELName,Designation,Emp_Email,Emp_Contact_Number,D_id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.status(201).json({ message: "Product added successfully", id: result.insertId });
    });
});



//Book
// GET all Books
app.get('/Book', (req, res) => {
    const sql = "SELECT * FROM Book";
    db.query(sql, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json(data);
    });
});

// POST a new Book
app.post('/Book', (req, res) => {
    const Availability = true
    const { Book_ID, Title, Author, Year, Subject_Matter } = req.body;
    const sql = "INSERT INTO Book (Book_ID, Title, Author, Year, Subject_Matter, Availability) VALUES (?, ?, ?, ?, ?, ?)";
    db.query(sql, [Book_ID, Title, Author, Year, Subject_Matter, Availability], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.status(201).json({ message: "Book added successfully", id: result.insertId });
    });
});


// DELETE  the book_info
app.delete('/Book/:Book_ID', (req, res) => {
    const productId = req.params.Book_ID;
    const sql = "DELETE FROM Book WHERE Book_ID = ?;";
    db.query(sql, [productId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Book not found" });
        }
        return res.json({ message: "Book deleted successfully" });
    });
});

//Rack_info

// GET all Rack_info
app.get('/Rack_info', (req, res) => {
    const sql = "SELECT * FROM Rack_info";
    db.query(sql, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json(data);
    });
});

// POST a new rack_info
app.post('/Rack_info', (req, res) => {
    const { Subject_Matter, Rack_Number} = req.body;
    const sql = "INSERT INTO products (Subject_Matter, Rack_Numbe) VALUES (?, ?)";
    db.query(sql, [Subject_Matter, Rack_Number], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.status(201).json({ message: "Product added successfully", id: result.insertId });
    });
});

// PUT (update) a rack_info
app.put('/Rack_info/:Subject_Matter', (req, res) => {
    const productId = req.params.Subject_Matter;
    const { Rack_Number } = req.body;
    const sql = "UPDATE Rack_info SET Rack_Number = ? WHERE Subject_Matter = ?";
    db.query(sql, [Rack_Number, productId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Product not found" });
        }
        return res.json({ message: "Product updated successfully" });
    });
});

// DELETE a rack
app.delete('/Rack_info/:Subject_Matter', (req, res) => {
    const productId = req.params.Subject_Matter;
    const sql = "DELETE FROM Rack_info WHERE Subject_Matter = ?;";
    db.query(sql, [productId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Product not found" });
        }
        return res.json({ message: "Product deleted successfully" });
    });
});

//Department

// GET all Departments
app.get('/Department', (req, res) => {
    const sql = "SELECT * FROM Department";
    db.query(sql, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json(data);
    });
});

// POST a new Department
app.post('/Department', (req, res) => {
    const { Dept_ID, Dept_Name } = req.body;
    const sql = "INSERT INTO products (Dept_ID,Dept_Name) VALUES (?, ?)";
    db.query(sql, [Dept_ID,Dept_Name], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.status(201).json({ message: "Product added successfully", id: result.insertId });
    });
});



//Issued_Books

// GET all I_Books
app.get('/Issued_Books', (req, res) => {
    const sql = "SELECT * FROM Issued_Books WHERE S_ID=?";
    db.query(sql, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json(data);
    });
});

// POST a new I_Book
app.post('/Issued_Books', (req, res) => {
    const Returned = false;
    const { S_ID,B_ID,Due_Date } = req.body;
    const sql = "INSERT INTO Issued_Books (S_ID,B_ID,Due_Date,Returned) VALUES (?, ?, ?, ?)";
    db.query(sql, [S_ID,B_ID,Due_Date,Returned], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.status(201).json({ message: "Product added successfully", id: result.insertId });
    });
});

// PUT (update) a I_book
app.put('/Issued_Books', (req, res) => {
    const { B_ID, S_ID, Due_Date } = req.body;
    const { Returned } = req.body;
    const sql = "UPDATE Issued_books SET Returned = ? WHERE B_ID = ? AND S_ID = ? AND Due_Date = ?";
    db.query(sql, [Returned,B_ID,S_ID,Due_Date], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Product not found" });
        }
        return res.json({ message: "Product updated successfully" });
    });
});

// DELETE a I_Book
app.delete('/Issued_Books/:S_Id', (req, res) => {
    const productId = req.params.id;
    const sql = "DELETE FROM products WHERE S_Id = ?";
    db.query(sql, [productId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Product not found" });
        }
        return res.json({ message: "Product deleted successfully" });
    });
});

//Fine
// GET all Dues
app.get('/Fine', (req, res) => {
    const sql = "SELECT * FROM Fine";
    db.query(sql, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json(data);
    });
});

// POST a new Due
app.post('/Fine', (req, res) => {
    const { Std_id,B_id,Fine_amnt } = req.body;
    const sql = "INSERT INTO products (Std_id,B_id,Fine_amnt) VALUES (?, ?, ?)";
    db.query(sql, [Std_id,B_id,Fine_amnt], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.status(201).json({ message: "Product added successfully", id: result.insertId });
    });
});





//Isuued_by

// GET all Issued_by
app.get('/Issued_by', (req, res) => {
    const sql = "SELECT * FROM Issued_by";
    db.query(sql, (err, data) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.json(data);
    });
});

// POST a new Issuer
app.post('/Issued_by', (req, res) => {
    const { Id,E_Id,Issued_Date } = req.body;
    const sql = "INSERT INTO Issued_by (Id,E_Id,Issued_Date) VALUES (?, ?, ?)";
    db.query(sql, [Id,E_Id,Issued_Date], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        return res.status(201).json({ message: "Product added successfully", id: result.insertId });
    });
});

//join
app.get('/books', (req, res) => {
    const sql = "SELECT ib.B_ID AS BookId, b.Title AS booktitle, ib.Issued_Date AS issueddate, CONCAT(e.EFName, ' ', e.EMName, ' ', e.ELName) AS issuedby, ib.Due_Date AS due_date FROM issued_books ib INNER JOIN Book b ON ib.Book_ID = b.Book_ID INNER JOIN IssuedBy iby ON ib.E_Id = iby.E_Id INNER JOIN Employee e ON iby.E_Id = e.Emp_Id WHERE ib.S_ID=?";
    
    db.query(sql, (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(result);
    });
});

//join2
app.get('/books', (req, res) => {
    const sql = "SELECT ib.B_ID AS BookId, b.Title AS booktitle, ib.Issued_Date AS issueddate, CONCAT(e.EFName, ' ', e.EMName, ' ', e.ELName) AS issuedby, ib.Due_Date AS due_date FROM issued_books ib INNER JOIN Book b ON ib.Book_ID = b.Book_ID INNER JOIN IssuedBy iby ON ib.E_Id = iby.E_Id INNER JOIN Employee e ON iby.E_Id = e.Emp_Id WHERE ib.S_ID=?";
    
    db.query(sql, (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(result);
    });
});


app.listen(8081,() =>{
    console.log("listening on port 8081");
})