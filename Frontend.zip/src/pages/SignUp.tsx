import React from "react";
import NavBar from "../components/NavBarHome";
import "./SignUp.css";
import { useNavigate } from "react-router-dom";
import { useState, ChangeEvent, FormEvent} from "react";

const SignUp = () => {
  let [formData, setFormData] = useState({
    firstName: "",
    middleName: "",
    lastName: "",
    studentId: "",
    department: "",
    email: "",
    contactNumber: "",
    password: "",
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

 
  const handleSubmit = (e: any) => {  
    e.preventDefault();
    console.log("123");
    console.log(formData);

    fetch('http://localhost:8081/Student', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({FName:formData.firstName,MName:formData.middleName,LName:formData.lastName,Student_ID:formData.studentId,Course_Department:formData.department,Email:formData.email,Phone_Number:formData.contactNumber,password:formData.password})
    })
      .then(response => response.json())
      .then(data => {
        console.log(data);
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };
  const navigate = useNavigate();
  const redirectToPage = () => {
    navigate("#");
  };
  return (
    <div>
      <NavBar />
      <div className="container">
        <div className="header">
          <div className="text">Sign Up</div>
        </div>
        <form>
          <input
            type="text"
            placeholder="First Name"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
          />
          <input
            type="text"
            placeholder="Middle Name"
            name="middleName"
            value={formData.middleName}
            onChange={handleChange}
          />
          <input
            type="text"
            placeholder="Last Name"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
          />
          <input
            type="text"
            placeholder="Student ID"
            name="studentId"
            value={formData.studentId}
            onChange={handleChange}
          />
          <input
            type="text"
            placeholder="Course Department"
            name="department"
            value={formData.department}
            onChange={handleChange}
          />
          <input
            type="text"
            placeholder="Email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
          <input
            type="text"
            placeholder="Contact Number"
            name="contactNumber"
            value={formData.contactNumber}
            onChange={handleChange}
          />
          <input
            type="password"
            placeholder="Password"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />
          <input type="password" placeholder="Re-type Password" />
        </form>
        <button type ="submit" className="signup-button" onClick={handleSubmit}>
          Create Account
        </button>
        <div className="member">
          Already registered? <a href="/StudentLogin">Log In</a>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
// FormEvent<HTMLInputElement>