import React from "react";
import { useNavigate } from "react-router-dom";
import NavBarEmployer from "../components/NavBarEmployer";
import { useState, ChangeEvent, FormEvent } from "react";

const IssueBooks = () => {
  const [formData, setFormData] = useState({
    bookId: "",
    studentId: "",
    issueDate: "",
    dueDate: "",
    issuedBy: "",
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e: any) => {  
    e.preventDefault();
    console.log(formData);

    fetch('http://localhost:8081/Issued_Books', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({S_ID:formData.studentId,B_ID:formData.bookId,Due_Date:formData.dueDate})
    })
      .then(response => response.json())
      .then(data => {
        console.log(data);
      })
      .catch(error => {
        console.error('Error:', error);
      });

      fetch('http://localhost:8081/Issued_by', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({Id:formData.bookId,E_Id:formData.issuedBy,Issued_Date:formData.issueDate})
    })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        alert("Book IssuedSuccessfully");
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };

  const navigate = useNavigate();
  const redirectToPage = () => {
    navigate("#");
  };
  return (
    <div>
      <NavBarEmployer />
      <div className="container">
        <div className="header">
          <div className="text">Fill in the details below</div>
        </div>
        <form>
          <input
            type="text"
            placeholder="Book ID"
            name="bookId"
            value={formData.bookId}
            onChange={handleChange}
          />
          <input
            type="text"
            placeholder="Student ID"
            name="studentId"
            value={formData.studentId}
            onChange={handleChange}
          />
          <input
            type="text"
            placeholder="Issue Date"
            name="issueDate"
            value={formData.issueDate}
            onChange={handleChange}
          />
          <input
            type="text"
            placeholder="Due Date"
            name="dueDate"
            value={formData.dueDate}
            onChange={handleChange}
          />
          <input
            type="text"
            placeholder="Issued By (Employer ID)"
            name="issuedBy"
            value={formData.issuedBy}
            onChange={handleChange}
          />
        </form>
        <button className="signup-button" onClick={handleSubmit}>
          Issue Book
        </button>
      </div>
    </div>
  );
};

export default IssueBooks;