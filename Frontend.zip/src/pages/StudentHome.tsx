import React from "react";
import NavBarStudent from "../components/NavBarStudent";
import SearchBar from "../components/SearchBar";

const StudentHome = () => {
  return (
    <div>
      <NavBarStudent />
      <SearchBar />
    </div>
  );
};

export default StudentHome;
