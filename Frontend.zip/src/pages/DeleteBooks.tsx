import React from "react";
import NavBarEmployer from "../components/NavBarEmployer";
import SearchBar from "../components/SearchBar";
import "./DeleteBooks.css"

const DeleteBooks = () => {
  const books = [
    {
      id: 1,
      name: "Book 1",
      genre: "Fiction",
      author: "Author 1",
      year: 2000,
      availability: "Available",
      rackNumber: "A1",
    },
    {
      id: 2,
      name: "Book 2",
      genre: "Non-Fiction",
      author: "Author 2",
      year: 2010,
      availability: "Unavailable",
      rackNumber: "B2",
    },
    {
      id: 3,
      name: "Book 3",
      genre: "Fantasy",
      author: "Author 3",
      year: 2020,
      availability: "Available",
      rackNumber: "C3",
    },
    // Add more books as needed
  ];

  return (
    <div>
        <NavBarEmployer />
          <SearchBar />
        <table className="table">
          <thead>
            <tr>
              <th>Book Id</th>
              <th>Book Name</th>
              <th>Book Genre</th>
              <th>Book Author</th>
              <th>Year of Publication</th>
              <th>Availability</th>
              <th>Rack Number</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {books.map((book) => (
              <tr key={book.id}>
                <td>{book.id}</td>
                <td>{book.name}</td>
                <td>{book.genre}</td>
                <td>{book.author}</td>
                <td>{book.year}</td>
                <td>{book.availability}</td>
                <td>{book.rackNumber}</td>
                <td>
                  <div className="action-buttons">
                    <button>Edit</button>
                    <button>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
    </div>
  );
};

export default DeleteBooks;