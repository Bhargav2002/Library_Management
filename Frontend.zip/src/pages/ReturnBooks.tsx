import React from "react";
import "./ReturnBooks.css";
import { useState } from "react";
import NavBarEmployer from "../components/NavBarEmployer";
import SearchBar from "../components/SearchBar";

function ReturnBooks() {
  const [books, setBooks] = useState([
    {
      id: 1,
      name: "Book 1",
      genre: "Fiction",
      author: "Author 1",
      year: 2000,
      issued: true,
    },
    {
      id: 2,
      name: "Book 2",
      genre: "Non-Fiction",
      author: "Author 2",
      year: 2010,
      issued: true,
    },
    {
      id: 3,
      name: "Book 3",
      genre: "Fantasy",
      author: "Author 3",
      year: 2020,
      issued: false,
    },
    // Add more books as needed
  ]);

  const handleReturn = (id: number) => {
    const updatedBooks = books.map((book) => {
      if (book.id === id) {
        return { ...book, issued: false };
      }
      return book;
    });
    setBooks(updatedBooks);
    // Here you can send an update to the backend
    // For demonstration purpose, I'll log the updated books to the console
    console.log(updatedBooks);
  };

  return (
    <div>
      <NavBarEmployer />
      <SearchBar />
      <table className="table">
        <thead>
          <tr>
            <th>Book Name</th>
            <th>Book ID</th>
            <th>Book Genre</th>
            <th>Book Author</th>
            <th>Year of Publication</th>
            <th>Issued Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr key={book.id}>
              <td>{book.name}</td>
              <td>{book.id}</td>
              <td>{book.genre}</td>
              <td>{book.author}</td>
              <td>{book.year}</td>
              <td>{book.issued ? "Issued" : "Returned"}</td>
              <td>
                {book.issued ? (
                  <button onClick={() => handleReturn(book.id)}>Return</button>
                ) : (
                  <span>No Action</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ReturnBooks;
