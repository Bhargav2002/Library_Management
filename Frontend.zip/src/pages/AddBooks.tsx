import React from "react";
import NavBarEmployer from "../components/NavBarEmployer";
import { useNavigate } from "react-router-dom";
import "./SignUp.css";
import { useState, ChangeEvent, FormEvent } from "react";

const AddBooks = () => {
  let [formData, setFormData] = useState({
    bookId: "",
    title: "",
    author: "",
    year: "",
    subjectMatter: "",
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e: any) => {  
    e.preventDefault();
    console.log("123");
    console.log(formData);

    fetch('http://localhost:8081/Book', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({Book_ID:formData.bookId,Title:formData.title,Author:formData.author,Year:formData.year,Subject_Matter:formData.subjectMatter})
    })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        alert("Book Added Successfully")
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };
  
  return (
    <div>
      <NavBarEmployer />
      <div className="container">
        <div className="header">
          <div className="text">Fill in the details below</div>
        </div>
        <form>
        <input type="text" placeholder="Book ID" name="bookId"
            value={formData.bookId}
            onChange={handleChange}/>
          <input type="text" placeholder="Title" name="title"
            value={formData.title}
            onChange={handleChange}/>
          <input type="text" placeholder="Author" name="author"
            value={formData.author}
            onChange={handleChange}/>
          <input type="text" placeholder="Year of Publication" name="year"
            value={formData.year}
            onChange={handleChange}/>
          <input type="text" placeholder="Subject Matter" name="subjectMatter"
            value={formData.subjectMatter}
            onChange={handleChange}/>
        </form>
        <button className="signup-button" onClick={handleSubmit}>
          Add
        </button>
      </div>
    </div>
  );
};

export default AddBooks;
