import React from "react";
import { useNavigate } from "react-router-dom";
import NavBarStudent from "../components/NavBarStudent";

const UpdateProfile = () => {
  const navigate = useNavigate();
  const redirectToPage = () => {
    navigate("#");
  };
  return (
    <div>
      <NavBarStudent />
      <div className="container">
        <div className="header">
          <div className="text">Fill in the details below</div>
        </div>
        <form action="">
          <input type="text" placeholder="First Name" />
          <input type="text" placeholder="Middle Name" />
          <input type="text" placeholder="Last Name" />
          <input type="text" placeholder="Email" />
          <input type="text" placeholder="Contact Number" />
        </form>
        <button className="signup-button" onClick={redirectToPage}>
          Update
        </button>
      </div>
    </div>
  );
};

export default UpdateProfile;
