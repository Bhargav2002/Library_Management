import React from "react";
import NavBarEmployer from "../components/NavBarEmployer";
import SearchBar from "../components/SearchBar";
import Dropdown from 'react-bootstrap/Dropdown';

const EmployerHome = () => {
  const l = "/EmployerLogin";
  return (
    <div>
      <NavBarEmployer />
      <SearchBar />
    </div>
  );
};

export default EmployerHome;
