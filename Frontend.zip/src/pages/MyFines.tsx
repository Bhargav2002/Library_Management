import React from "react";
import NavBarStudent from "../components/NavBarStudent";
import SearchBar from "../components/SearchBar";

const MyFines = () => {
  const books = [
    { id: 1, title: "Book 1", dueDate: "2024-05-10", fineAmount: "$5.00" },
    { id: 2, title: "Book 2", dueDate: "2024-05-05", fineAmount: "$3.50" },
    { id: 3, title: "Book 3", dueDate: "2024-05-01", fineAmount: "$7.00" },
    // Add more books as needed
  ];

  return (
    <div>
      <NavBarStudent />
      <SearchBar />
      <table className="table">
        <thead>
          <tr>
            <th>Book ID</th>
            <th>Book Title</th>
            <th>Due Date</th>
            <th>Fine Amount</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr key={book.id}>
              <td>{book.id}</td>
              <td>{book.title}</td>
              <td>{book.dueDate}</td>
              <td>{book.fineAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MyFines;
