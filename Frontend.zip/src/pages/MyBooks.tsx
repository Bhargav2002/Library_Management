import React from "react";
import NavBarStudent from "../components/NavBarStudent";
import "./ReturnBooks.css"
import SearchBar from "../components/SearchBar";

const MyBooks = ({b}:any) => {
//   const books = [
//     {
//       id: 1,
//       title: "Book 1",
//       issuedDate: "2024-04-10",
//       issuedBy: "John Doe",
//       dueDate: "2024-05-10",
//     },
//     {
//       id: 2,
//       title: "Book 2",
//       issuedDate: "2024-04-05",
//       issuedBy: "Jane Smith",
//       dueDate: "2024-05-05",
//     },
//     {
//       id: 3,
//       title: "Book 3",
//       issuedDate: "2024-04-01",
//       issuedBy: "Alice Johnson",
//       dueDate: "2024-05-01",
//     },
//     // Add more books as needed
//   ];

  return (
    <div>
        <NavBarStudent />
        <SearchBar />
        <table className="table">
          <thead>
            <tr>
              <th>Book ID</th>
              <th>Book Title</th>
              <th>Issued Date</th>
              <th>Issued By</th>
              <th>Due Date</th>
            </tr>
          </thead>
          <tbody>
            {b.map((book:any) => (
              <tr key={book.id}>
                <td>{book.id}</td>
                <td>{book.title}</td>
                <td>{book.issuedDate}</td>
                <td>{book.issuedBy}</td>
                <td>{book.dueDate}</td>
              </tr>
            ))}
          </tbody>
        </table>
    </div>
  );
};

export default MyBooks;
