import React from "react";
import NavBar from "../components/NavBarHome";
import { useState } from "react";
import "./StudentLogin.css";
import { useNavigate } from "react-router-dom";

const StudentLogin = () => {
  const [username, setUsername] = useState("");
  const [pass, setPass] = useState("");
  const navigate = useNavigate();
  const redirectToPage = () => {
    navigate("/StudentHome");
  };

  return (
    <div>
      <NavBar />
      <div className="container-login">
        <div className="header">
          <div className="text">Sign In</div>
        </div>
        <div className="inputs">
          <div className="input-box">
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Email"
            ></input>
          </div>
          <div className="input-box">
            <input
              value={pass}
              onChange={(e) => setPass(e.target.value)}
              placeholder="Password"
            ></input>
          </div>
        </div>
        <button className="submit" onClick={redirectToPage}>
          Login
        </button>
      </div>
    </div>
  );
};

export default StudentLogin;
