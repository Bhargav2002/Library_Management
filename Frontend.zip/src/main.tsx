import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "bootstrap/dist/css/bootstrap.css";
import "./App.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import StudentLogin from "./pages/StudentLogin";
import EmployerLogin from "./pages/EmployerLogin";
import SignUp from "./pages/SignUp";
import EmployerHome from "./pages/EmployerHome";
import AddBooks from "./pages/AddBooks";
import DeleteBooks from "./pages/DeleteBooks";
import IssueBooks from "./pages/IssueBooks";
import ReturnBooks from "./pages/ReturnBooks";
import StudentHome from "./pages/StudentHome";
import MyBooks from "./pages/MyBooks";
import MyFines from "./pages/MyFines";
import UpdateProfile from "./pages/UpdateProfile";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
  },
  {
    path: "StudentLogin",
    element: <StudentLogin />,
  },
  {
    path: "EmployerLogin",
    element: <EmployerLogin />,
  },
  {
    path: "SignUp",
    element: <SignUp />,
  },
  {
    path: "EmployerHome",
    element: <EmployerHome />,
  },
  {
    path: "AddBooks",
    element: <AddBooks />,
  },
  {
    path: "DeleteBooks",
    element: <DeleteBooks />,
  },
  {
    path: "IssueBooks",
    element: <IssueBooks />,
  },
  {
    path: "ReturnBooks",
    element: <ReturnBooks />,
  },
  {
    path: "StudentHome",
    element: <StudentHome />,
  },
  {
    path: "MyBooks",
    element: <MyBooks />,
  },
  {
    path: "MyFines",
    element: <MyFines />,
  },
  {
    path: "UpdateProfile",
    element: <UpdateProfile />,
  },
]);

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
