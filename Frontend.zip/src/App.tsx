import Heading from "./components/Heading";
import NavBar from "./components/NavBarHome";
import SearchBar from "./components/SearchBar";
import Table from "./pages/ReturnBooks";
import NavBarEmployer from "./components/NavBarEmployer";
import Button from "./components/Button";


function App() {
  return (
    <>
      <NavBar />
      <SearchBar />
    </>
  );
}

export default App;
