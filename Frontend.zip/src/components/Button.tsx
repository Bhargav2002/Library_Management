import React from "react";
import { useNavigate } from "react-router-dom";
import "./Button.css";

const Button = ({lk,cls} : any) => {
  const navigate = useNavigate();
  const redirectToPage = () => {
    navigate(lk);
  };
  return (
    <div className="big-container">
      <button className={cls} onClick={redirectToPage}>
        Add Book
      </button>
    </div>
  );
};

export default Button;
