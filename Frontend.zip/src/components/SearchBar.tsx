import React, { useState } from "react";
import { FaSearch } from "react-icons/fa";
import "./SearchBar.css";

const SearchBar = () => {
  const [Input, setInput] = useState("");
  return (
    <div className="input-wrapper">
      <FaSearch id="search-icon" />
      <input
        placeholder="Search for Books, Authors,...."
        value={Input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button className="submit-button">Search</button>
    </div>
  );
};

export default SearchBar;
