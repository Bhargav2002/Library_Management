import React from "react";
import DropDown from "./DropDown";
import { Link } from "react-router-dom";

const NavBarEmployer = () => {
  return (
    <div className="navbar">
      <div className="title">Library Management System</div>
      <ul className="navbar-content">
        <li>
          <Link to={"/EmployerHome"}>Home</Link>
        </li>
        <li>
          <DropDown
            name={"Inventory"}
            a={"Add Books"}
            b={"Delete/Update Books"}
            l1={"/AddBooks"}
            l2={"/DeleteBooks"}
          />
        </li>
        <li>
          <DropDown
            name={"Transactions"}
            a={"Issue Books"}
            b={"Return Books"}
            l1={"/IssueBooks"}
            l2={"/ReturnBooks"}
          />
        </li>
        <li>
          <Link to={"/EmployerLogin"}>Logout</Link>
        </li>
      </ul>
    </div>
  );
};

export default NavBarEmployer;
