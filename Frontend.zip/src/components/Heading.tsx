function Heading() {
  return (
    <header className="App-header">
      <h1>Library Management System</h1>
    </header>
  );
}
export default Heading;
