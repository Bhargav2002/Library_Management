import React from "react";
import { Link } from "react-router-dom";
import DropDown from "./DropDown";
import "./NavBar.css";
import { useState } from "react";
import MyBooks from "../pages/MyBooks";

const NavBarStudent = () => {
  const [data, setData] = useState([]);
  const books = [
    {
      id: 1,
      title: "Book 1",
      issuedDate: "2024-04-10",
      issuedBy: "John Doe",
      dueDate: "2024-05-10",
    },
    {
      id: 2,
      title: "Book 2",
      issuedDate: "2024-04-05",
      issuedBy: "Jane Smith",
      dueDate: "2024-05-05",
    },
    {
      id: 3,
      title: "Book 3",
      issuedDate: "2024-04-01",
      issuedBy: "Alice Johnson",
      dueDate: "2024-05-01",
    },
    // Add more books as needed
  ];

  const fetchData = () => {
    
    return <MyBooks b={books} />;
  };
  return (
    <div className="navbar">
      <div className="title">Library Management System</div>
      <ul className="navbar-content">
        <li>
          <Link to="/StudentHome">Home</Link>
        </li>
        <li>
          <Link to="/MyBooks">
            <button className="navbar-button" onClick={fetchData}>
              My Books
            </button>
          </Link>
        </li>
        <li>
          <Link to="/MyFines">
            <button className="navbar-button">My Fines</button>
          </Link>
        </li>
        <li>
          <Link to="/UpdateProfile">Update Profile</Link>
        </li>
        <li>
          <Link to="/StudentLogin">
            <button className="navbar-button">Logout</button>
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default NavBarStudent;
