import Dropdown from 'react-bootstrap/Dropdown';
import "./DropDown.css"

function DropDown({name,a,b,l1,l2}:any) {
  return (
    <div>
    <Dropdown>
      <Dropdown.Toggle id="dropdown-basic">
        {name}
      </Dropdown.Toggle>

      <Dropdown.Menu>
        <Dropdown.Item className = "item" href={l1}>{a}</Dropdown.Item>
        <Dropdown.Item className = "item" href={l2}>{b}</Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
    </div>
  );
}

export default DropDown;
