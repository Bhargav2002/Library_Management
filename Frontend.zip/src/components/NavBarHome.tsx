import React from "react";
import "./NavBar.css";
import { Link } from "react-router-dom";
import DropDown from "./DropDown";
const NavBar = () => {
  return (
    <div className="navbar">
      <div className="title">Library Management System</div>
      <ul className="navbar-content">
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/SignUp">For Students</Link>
        </li>
        <li>
          <Link to="/EmployerLogin">For Employers</Link>
        </li>
      </ul>
    </div>
  );
};

export default NavBar;
